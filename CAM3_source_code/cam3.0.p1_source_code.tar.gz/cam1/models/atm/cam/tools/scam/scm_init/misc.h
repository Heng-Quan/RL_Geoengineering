#ifndef MISC_SET
#define MISC_SET
#define SCAM
#undef PERGRO
#undef SPMD
#endif
