#ifndef REALTYPE_H
#define REALTYPE_H


/* REAL_TYPE is used to set the precision with which scam and
   scamgui exchange data, and the precision with which scamgui
   saves the history output; defaults to float if not specified
*/

typedef double real_t;

#endif /* REALTYPE_H */
