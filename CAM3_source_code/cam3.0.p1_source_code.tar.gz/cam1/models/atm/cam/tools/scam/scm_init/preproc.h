#ifndef PREPROC_SET
#define PREPROC_SET
#define COUP_CAM
#define LSMLON 1
#define LSMLAT 1
#endif
