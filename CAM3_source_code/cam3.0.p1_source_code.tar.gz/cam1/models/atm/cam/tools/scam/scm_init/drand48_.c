#include <stdlib.h>

double drand48_()
{
  return(drand48());;
}

