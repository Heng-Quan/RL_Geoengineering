/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename slots use Qt Designer which will
** update this file, preserving your code. Create an init() slot in place of
** a constructor, and a destroy() slot in place of a destructor.
*****************************************************************************/


void OptionsDlg::ApplyChanges()
{

}

void OptionsDlg::CancelChanges()
{

}

void OptionsDlg::ChooseInitialDataset( int )
{

}

void OptionsDlg::QuickStartFileName( bool )
{

}

void OptionsDlg::ShowCurrentSettings()
{

}

void OptionsDlg::init()
{

}

void OptionsDlg::SicFileName( bool )
{

}


void OptionsDlg::ChooseBoundaryDataset( int )
{

}

void OptionsDlg::ChooseIOPDataset( int )
{

}

void OptionsDlg::ChooseDataset( int )
{

}

void OptionsDlg::ButtonGroup7_clicked( int )
{

}


void OptionsDlg::SetSeedValue()
{

}


void OptionsDlg::SetSeedValue( int )
{

}
