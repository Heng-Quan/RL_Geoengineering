#ifndef PARAMS_SET
#define PARAMS_SET
#undef STAGGERED
#undef COUP_SOM
#endif
