#ifndef SCAMFIFOSRV_H
#define SCAMFIFOSRV_H

void server_init( int argc, char* argv[] );
int  server_run();

#endif /* SCAMFIFOSRV_H */
