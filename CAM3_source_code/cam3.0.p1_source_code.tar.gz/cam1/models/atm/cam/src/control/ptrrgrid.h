!----------------------------------------------------------------------- 
! 
! Purpose: Define radiation vertical grid
! 
! Author: CCM Core Group
! 
!-----------------------------------------------------------------------

      integer pverr    ! Number of vertical levels
      integer pverrp   ! pverr + 1
!
      parameter(pverr = PLEVR)
      parameter(pverrp = pverr + 1)
 
