!----------------------------------------------------------------------- 
! 
! Purpose: time filter coefficient
! 
!-----------------------------------------------------------------------
      common /comtfc/ eps

      real(r8) eps             ! Time filter coefficient
 
